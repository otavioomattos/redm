RSG = {}

RSG.WelcomeText = "BEM VINDO AO CONDADO DE DAKOTA"

RSG.ProfanityWords = {
    ['bad word'] = true,
    ['dick'] = true,
    ['ass'] = true
}

RSG.CameraPromptText = 'Up/Down'
RSG.RotatePromptText = 'Left/Right'
RSG.ZoomPromptText = 'Zoom'
RSG.GroupPromptText = 'Criador de Personagem'

RSG.Prompt = {
    MalePrompt = 0xA65EBAB4,
    FemalePrompt = 0xDEB34313,
    ConfirmPrompt = 0x2CD5343E,
    CameraUp = 0x8FD015D8,
    CameraDown = 0xD27782E3,
    RotateLeft = 0x7065027D,
    RotateRight = 0xB4E465B4,
    Zoom1 = 0x62800C92,
    Zoom2 = 0x8BDE7443,
}

RSG.Texts = {
    Body = "Corpo",
    Face = "Face",
    Hair_beard = "Cabelo e barba",
    HairStyle = "Penteado",
    HairColor = "Cor de cabelo",
    BeardStyle = "Estilo de barba",
    BeardColor = "Cor de barba",
    Makeup = "Makeup",
    Appearance = "Aparência",
    Slim = "Magro",
    Sporty = "Esportiva",
    Medium = "Média",
    Fat = "Gorda",
    Strong = "Forte",
    FaceWidth = "Largura do rosto",
    SkinTone = "Tom de pele",
    Eyes = "Olhos",
    Eyelids = "Pálpebras",
    Eyebrows = "Sobrancelhas",
    Nose = "Nariz",
    Mouth = "Boca",
    Teeth = "Dentes",
    Cheekbones = "Ossos da bochecha",
    Jaw = "Mandíbula",
    Ears = "Ouvidos",
    Chin = "Queixo",
    Defects = "Defeitos",
    Hair = "Cabelo",
    Beard = "Beard",
    Type = "Tipo",
    Visibility = "Visibilidade",
    ColorPalette = "Paleta de cores ",
    ColorFirstrate = "Colorir a primeira classe",
    Eyebrow = "Sobrancelhas",
    NoseCurvature = "Curvatura do nariz",
    UP_DOWN = "CIMA / BAIXO",
    left_right = "esquerda / direita",
    UpperLipHeight = "Altura do lábio superior",
    UpperLipWidth = "Largura do lábio superior",
    UpperLipDepth = "Profundidade do lábio superior",
    LowerLipHeight = "Altura dos lábios inferiores",
    LowerLipWidth = "Largura labial inferior",
    LowerLipDepth = "Profundidade dos lábios inferiores",
    Make_up = "Make-up",
    Older = "Mais velho",
    Scars = "Tipo de cicatrizes",
    Freckles = "Tipo sardas",
    Moles = "Toupeiras",
    Disadvantages = "Desvantagens",
    Spots = "Polainas",
    Shadow = "Sombra",
    ColorShadow = "Cor da sombra",
    ColorFirst_Class = "Colorir ilusão de primeira classe",
    Blushing_Cheek = "Bochecha corada",
    blush_id = "Cor de blush",
    blush_c1 = "Colorir a vermelhidão da bochecha em primeiro grau",
    Lipstick = "Tipo de batom",
    ColorLipstick = "Batom de cor",
    lipsticks_c1 = "Batom colorido de primeira classe",
    lipsticks_c2 = "Segunda cor do batom",
    Eyeliners = "Delineadores",
    eyeliners_id = "Cores de delineadores",
    eyeliners_c1 = "Colorir delineadores principais",
    save = "Salvar",
    Options = "Opções",
    align = "superior esquerda",
    Style = "Estilo ",
    Color = "Cor ",
    Size = "Tamanho",
    Width = "Largura ",
    Height = "Altura",
    Depth = "Profundidade",
    Waist = "Cintura",
    Chest = "Peito",
    Distance = "Distância",
    Angle = "Ângulo",
    Clarity = "Clareza",
    Color1 = "<img src='nui://rsg-appearance/img/skin1.png' height='20'>",
    Color2 = "<img src='nui://rsg-appearance/img/skin2.png' height='20'>",
    Color3 = "<img src='nui://rsg-appearance/img/skin3.png' height='20'>",
    Color4 = "<img src='nui://rsg-appearance/img/skin4.png' height='20'>",
    Color5 = "<img src='nui://rsg-appearance/img/skin5.png' height='20'>",
    Color6 = "<img src='nui://rsg-appearance/img/skin6.png' height='20'>",
    Creator = "CRIE SEU PERSONAGEM",


    firsmenu = {
        label_firstname = "Primeiro nome",
        label_lastname = "Sobrenome",
        desc = "Como você quer ser chamado por pessoas?",
        none = "Vazia",
        Start = "Comece sua jornada",
        empty = "Preencha tudo primeiro",
        Nationality = "Nacionalidade",
        Birthdate = "Data de nascimento",
    }
}

--Clothing store

RSG.Cloakroomtext = 'Aberto dos vestiários'
RSG.BlipName = 'Loja de roupas' -- Blip Name Showed on map
RSG.BlipNameCloakRoom = 'Guarda-roupa' -- Blip Name Showed on map
RSG.BlipSprite = 1195729388	 -- Clothing shop sprite
RSG.BlipSpriteCloakRoom = 1496995379	 -- Clothing shop sprite
RSG.BlipScale = 0.2 -- Blip scale
RSG.OpenKey = 0xD9D0E1C0 -- Opening key hash
RSG.Keybind = 'ENTER' -- keybind
RSG.ShowPlayerBucket = true -- prints to server the player routing bucket

RSG.SetDoorState = {
    -- open = 0 / locked = 1
    { door = 3554893730, state = 1 }, -- valentine
    { door = 2432590327, state = 1 }, -- rhodes
    { door = 3804893186, state = 1 }, -- saint dennis
    { door = 3277501452, state = 1 }, -- blackwater
    { door = 94437577,   state = 1 }, -- strawberry
    { door = 3315914718, state = 1 }, -- armadillo
    { door = 3208189941, state = 1 }, -- tumbleweed
} 

RSG.prompt_select = 0xC7B5340A   -- NUM ENTER
RSG.CameraWS = { 0x8FD015D8, 0xD27782E3 }    -- W and S
RSG.Rotate = { 0x7065027D, 0xB4E465B4 }  -- A and D
RSG.Zoom = { 0x62800C92, 0x8BDE7443 }    -- MOUSE SCROLL UP and MOUSE SCROLL DOWN

RSG.MakeupStores = {
    {
        Name = 'Loja de Maquiagem',  -- Clothing store name
        id = 'makeupstore',
        Blip = { 
            Enable = true, -- true or false (enable or disable blip)
            Sprite = 'blip_shop_tailor',    -- blip sprite
        },
        Coords = {
            blip = vector3(2548.604,-1158.289,53.725),
            Room = vector4(2555.76, -1161.43, 52.75, 345.15), -- vector4 (character coordinates in shop preview)
            Cam = vector4(2557.34, -1159.28, 53.75, 145.88), 
        },
    },
}

RSG.Zones1 = {

    --{
    --    location = 'valentine',
    --    blipcoords = vector3(-327.07, 807.77, 117.89),
    --    fittingcoords = vector4(-327.765, 807.769, 117.894, 254.593),
    --    quitcoords = vector4(-326.033, 805.976, 117.882, 241.450),
    --    promtcoords = vector3(-325.9504, 806.58251, 117.8897),
    --    showblip = true
    --},
    --{
    --    location = 'rhodes',
    --    blipcoords = vector3(1323.64, -1289.04, 77.02),
    --    fittingcoords = vector4(1324.265, -1287.926, 77.018, 150.606),
    --    quitcoords = vector4(1322.828, -1291.433, 77.028, 167.880),
    --    promtcoords = vector3(1322.9941, -1291.02, 77.031051),
    --    showblip = true
    --},
    --{
    --    location = 'saintdenis',
    --    blipcoords = vector3(2554.90, -1166.89, 53.68),
    --    fittingcoords = vector4(2555.500, -1161.000, 53.730, 310.371),
    --    quitcoords = vector4(2553.285, -1161.101, 53.684, 96.703),
    --    promtcoords = vector3(2554.9929, -1168.596, 53.68354),
    --    epromtcoords = vector3(2553.7929, -1161.27, 53.683544),
    --    showblip = true
    --},
    --{
    --    location = 'blackwater',
    --    blipcoords = vector3(-761.99, -1293.55, 43.84),
    --    fittingcoords = vector4(-767.951, -1294.627, 43.835, 250.153),
    --    quitcoords = vector4(-766.549, -1293.269, 43.836, 348.399),
    --    promtcoords = vector3(-762.0018, -1291.981, 43.853542),
    --    epromtcoords = vector3(-766.5512, -1293.67, 43.835578),
    --    showblip = true
    --},
    --{
    --    location = 'strawberry',
    --    blipcoords = vector3(-1793.4, -394.13, 160.34),
    --    fittingcoords = vector4(-1794.604, -395.540, 160.336, 317.471),
    --    quitcoords = vector4(-1791.907, -391.948, 160.266, 160.266),
    --    promtcoords = vector3(-1792.499, -392.3773, 160.35339),
    --    showblip = true
    --},
    --{
    --    location = 'armadillo',
    --    blipcoords = vector3(-3687.866, -2630.905, -13.40),
    --    fittingcoords = vector4(-3688.229, -2624.204, -10.218, 359.769),
    --    quitcoords = vector4(-3687.822, -2630.876, -13.395, 73.005),
    --    promtcoords = vector3(-3687.79, -2630.85, -13.39526),
    --    epromtcoords = vector3(-3687.168, -2622.447, -10.19031),
    --    showblip = true
    --},
    --{
    --    location = 'tumbleweed',
    --    blipcoords = vector3(-5480.13, -2933.97, -0.365),
    --    fittingcoords = vector4(-5479.786, -2932.66, -0.283, 166.096),
    --    quitcoords = vector4(-5481.510, -2935.005, -0.396, 85.180),
    --    promtcoords = vector3(-5480.852, -2934.573, -0.384145),
    --    showblip = true
    --},

}

RSG.Cloakroom = {
    --vector3(-325.29, 766.24, 117.48),   -- valentine
    --vector3(-1817.11, -368.77, 166.54), -- strawberry
    --vector3(-825.40, -1323.76, 47.91),  -- blackwater
    --vector3(1331.86, -1377.35, 80.55),  -- rhodes
    --vector3(2550.67, -1159.46, 53.73)   -- saint denis
}

RSG.Label = {
    boot_accessories    = 'Acessórios de inicialização',
    pants               = 'Calça',
    cloaks              = 'Mantos',
    hats                = 'Chapéus',
    vests               = 'Coletes',
    chaps               = 'Chaps',
    shirts_full         = 'Camisas cheias',
    badges              = 'Distintivos',
    masks               = 'Máscaras',
    spats               = 'Polainas',
    neckwear            = 'Desgaste do pescoço',
    boots               = 'Botas',
    accessories         = 'Acessórias',
    jewelry_rings_right = 'Anéis da mão direita',
    jewelry_rings_left  = 'Anéis da mão esquerda',
    jewelry_bracelets   = 'Pulseiras',
    gauntlets           = 'Manoplas',
    neckties            = 'Gravatas do pescoço',
    holsters_knife      = 'Faca de coldres',
    talisman_holster    = 'Talisman Holster',
    loadouts            = 'Load outs',
    suspenders          = 'Suspensórios',
    talisman_satchel    = 'Mochila com talismã',
    satchels            = 'Mochila',
    gunbelts            = 'Cintos de armas',
    belts               = 'Cintos',
    belt_buckles        = 'Fivelas de cinto',
    holsters_left       = 'Coldres',
    holsters_right      = 'Coldres secundário',
    talisman_wrist      = 'Pulso talismã',
    coats               = 'Casacos',
    coats_closed        = 'Casacos fechados',
    ponchos             = 'ponchos',
    eyewear             = 'Óculos',
    gloves              = 'Luvas',
    holsters_crossdraw  = 'Coldres cruzados',
    aprons              = 'Aventais',
    skirts              = 'Saias',
    hair_accessories    = 'Acessórios de cabelo',
    armor               = 'armaduras',
    dresses             = 'Vestidos',

    -- other

    save = 'Salve roupas',
    clothes = 'Roupas',
    options = 'opções',
    color = 'Cor ',
    choose = 'Escolha suas roupas',
    wear = 'Vestir roupas',
    wear_desc = 'vestir-se',
    delete = 'Excluir roupa',
    delete_desc = 'Excluir roupa',
    shop = 'Loja de roupas',
    total = 'Preço',
}

RSG.MenuElements = {
    ["head"] = {
        label = "Cabeça",
        category = {
            "hats",
            "eyewear",
            "masks",
            "neckwear",
            "neckties",
        }
    },

    ["torso"] = {
        label = "Tronco",
        category = {
            "cloaks",
            "vests",
            "shirts_full",
            "holsters_knife",
            "loadouts",
            "suspenders",
            "gunbelts",
            "belts",
            "holsters_left",
            "holsters_right",
            "coats",
            "coats_closed",
            "ponchos",
            "dresses",
        }
    },

    ["legs"] = {
        label = "Pernas",
        category = {
            "pants",
            "chaps",
            "skirts",
        }
    },
    ["foot"] = {
        label = "Pé",
        category = {
            "boots",
            "spats",
            "boot_accessories",
        }
    },

    ["hands"] = {
        label = "Mãos",
        category = {
            "jewelry_rings_right",
            "jewelry_rings_left",
            "jewelry_bracelets",
            "gauntlets",
            "gloves",
        }
    },

    ["accessories"] = {
        label = "Acessórios",
        category = {
            "accessories",
            "talisman_wrist",
            "talisman_holster",
            "belt_buckles",
            "satchels",
            "holsters_crossdraw",
            "aprons",
            "bows",
            "armor",
            "badges",
            "hair_accessories",
        }
    },
}


RSG.Price = {
    ["boot_accessories"] = 2,
    ["pants"] = 1,
    ["cloaks"] = 2,
    ["hats"] = 1,
    ["vests"] = 1,
    ["chaps"] = 1,
    ["shirts_full"] = 1,
    ["badges"] = 5,
    ["masks"] = 3,
    ["spats"] = 1,
    ["neckwear"] = 1,
    ["boots"] = 1,
    ["accessories"] = 2,
    ["jewelry_rings_right"] = 5,
    ["jewelry_rings_left"] = 5,
    ["jewelry_bracelets"] = 3,
    ["gauntlets"] = 1,
    ["neckties"] = 1,
    ["holsters_knife"] = 1,
    ["talisman_holster"] = 1,
    ["loadouts"] = 3,
    ["suspenders"] = 1,
    ["talisman_satchel"] = 1,
    ["satchels"] = 1,
    ["gunbelts"] = 1,
    ["belts"] = 1,
    ["belt_buckles"] = 3,
    ["holsters_left"] = 2,
    ["holsters_right"] = 2,
    ["talisman_wrist"] = 2,
    ["coats"] = 2,
    ["coats_closed"] = 3,
    ["ponchos"] = 3,
    ["eyewear"] = 2,
    ["gloves"] = 1,
    ["holsters_crossdraw"] = 2,
    ["aprons"] = 2,
    ["skirts"] = 1,
    ["hair_accessories"] = 1,
    ["dresses"] = 1,
    ["armor"] = 10,
}

RSG.Prompts = {
    {
        label = 'Loja de roupas',
        id = "OPEN_CLOTHING_MENU"
    },
    {
        label = 'Aumentar Zoom / Diminuir zoom',
        id = "ZOOM_IO",
        control = `INPUT_CURSOR_SCROLL_UP`,
        control2 = `INPUT_CURSOR_SCROLL_DOWN`,
        time = 0
    },
    {
        label = 'Câmera Cima / Baixo',
        id = "CAM_UD",
        control = `INPUT_MOVE_UP_ONLY`,
        control2 = `INPUT_MOVE_DOWN_ONLY`,
        time = 0
    },
    {
        label = 'Virar Esquerda / Direita',
        id = "TURN_LR",
        control = `INPUT_MOVE_LEFT_ONLY`,
        control2 = `INPUT_MOVE_RIGHT_ONLY`,
        time = 0
    },
}

--INPUT_RADIAL_MENU_NAV_UD
RSG.CreatedEntries = {}